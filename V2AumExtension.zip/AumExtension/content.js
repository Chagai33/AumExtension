function getSpotifySongDetails() {
  let nowPlayingElement = document.querySelector('[aria-label="now playing view link"]');
  if (!nowPlayingElement) {
    return {
      title: "N/A",
      artists: "N/A",
      trackId: "N/A"
    };
  }

  let trackId = nowPlayingElement.getAttribute('href').split(':').pop();
  let songTitleElement = document.querySelector('[data-testid="context-item-info-title"] a');
  let artistsContainer = document.querySelector('[data-testid="context-item-info-subtitles"]');
  let artistsElements = artistsContainer ? artistsContainer.querySelectorAll('[data-testid="context-item-info-artist"]') : [];

  let uniqueArtists = new Set();

  if (songTitleElement && artistsElements.length > 0) {
    let songTitle = songTitleElement.textContent;
    let artists = Array.from(artistsElements).map(a => {
      let artistName = a.textContent;
      let artistId = a.getAttribute('href').split('/').pop();
      return `<a href="https://open.spotify.com/artist/${artistId}" target="_blank">${artistName}</a>`;
    }).join(', ');

    return {
      title: songTitle,
      artists: artists,
      trackId: trackId
    };
  } else {
    return {
      title: songTitleElement ? songTitleElement.textContent : "N/A",
      artists: "N/A",
      trackId: trackId
    };
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getSongDetails') {
    sendResponse(getSpotifySongDetails());
  }
});
